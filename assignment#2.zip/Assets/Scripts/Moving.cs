using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Moving : MonoBehaviour
{
    // Start is called before the first frame update
    private MeshRenderer meshRenderer;
    public bool gameOverCheck = false;
    public float animationSpeed = 1f;
    void Start()
    {
        meshRenderer = GetComponent<MeshRenderer>();
    }

    // Update is called once per frame
    void Update()
    {
        if (gameOverCheck == false)
        { meshRenderer.material.mainTextureOffset += new Vector2(animationSpeed * Time.deltaTime, 0); }
    }
    public void GameOver()
    {
        gameOverCheck = true;
        FindObjectOfType<SpawnManager>().OnDisable();
        Time.timeScale = 0f;
    }

}
