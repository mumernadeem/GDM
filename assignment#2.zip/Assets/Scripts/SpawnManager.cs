using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnManager : MonoBehaviour
{
    // Start is called before the first frame update

    public GameObject prefab;
    public float spawnRate = 1f;
    public float minHeight = -1f;
    public float maxHeight = 2f;

    public void OnEnable()
    {
        InvokeRepeating(nameof(Spawn), spawnRate, spawnRate+1f);
    }

    public void OnDisable()
    {
        CancelInvoke(nameof(Spawn));
    }
    private void Update()
    {
        if (FindObjectOfType<Moving>().gameOverCheck == true)
        {
            Time.timeScale = 0f;
        }
    }
    private void Spawn()
    {
        GameObject obs = Instantiate(prefab, transform.position, Quaternion.identity);
        obs.transform.position += Vector3.up * Random.Range(minHeight, maxHeight);
    }
}
