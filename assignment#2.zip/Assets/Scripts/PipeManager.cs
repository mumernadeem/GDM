using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PipeManager : MonoBehaviour
{
   
    public float speed = 5f;
   // private float leftEdge;

    private void Start()
    {
      //  leftEdge = Camera.main.ScreenToWorldPoint(Vector3.zero).x - 1f;
    }

    private void Update()
    {
        transform.position += Vector3.left * speed * Time.deltaTime;

        if (transform.position.x < -12)
        {
           Destroy(gameObject);
        }
        if(FindObjectOfType<Moving>().gameOverCheck==true)
        {
            Time.timeScale = 0f;
        }
    }
    private void OnTriggerEnter(Collider other)
    {
        print("Game Over");
    }
}
