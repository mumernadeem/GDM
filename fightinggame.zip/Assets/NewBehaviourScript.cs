using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NewBehaviourScript : MonoBehaviour
{
    private float hortizontal, vertical, speed = 10f;
    private float leftSideRange = 4.4f;
    private float rightSideRange = -4.4f;
    private float topSideRange = -3.5f;
    private float bottomSideRange = 4.4f;
    public GameObject bullet;
    public Transform spawnPostion;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        hortizontal = Input.GetAxis("Horizontal");
        vertical = Input.GetAxis("Vertical");
        transform.Translate(Vector3.forward*vertical*speed*Time.deltaTime);
        transform.Translate(Vector3.right*hortizontal*speed*Time.deltaTime);
        if (transform.position.x > leftSideRange)
        {
            transform.position = new Vector3(leftSideRange,transform.position.y,transform.position.z);
        }
        if (transform.position.x < rightSideRange)
        {
            transform.position = new Vector3(rightSideRange,transform.position.y,transform.position.z);
        }
        if (transform.position.z > bottomSideRange)
        {
            transform.position = new Vector3(transform.position.x,transform.position.y, bottomSideRange);
        }
        if (transform.position.z < topSideRange)
        {
            transform.position = new Vector3(transform.position.x,transform.position.y, topSideRange);
        }
        if(Input.GetKeyDown(KeyCode.Space))
        {
            Instantiate(bullet, spawnPostion.position, spawnPostion.rotation);
        }
    }
}
