using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnManager : MonoBehaviour
{
    // Start is called before the first frame update
    public GameObject[] enemies;
    float xRange = 4.8f, zRange = -3.5f;
    void Start()
    {
        //Invoke("EnemySpawn", 3);   
        InvokeRepeating(nameof(EnemySpawn), 1,0.8f);   
    }

    // Update is called once per frame
    void Update()
    {
    }
    void EnemySpawn()
    {
           int enemyIndex=Random.Range(0,enemies.Length);
    Vector3 position = new Vector3(Random.Range(-xRange, xRange), 0.5f, zRange);
        Instantiate(enemies[enemyIndex], position, enemies[enemyIndex].transform.rotation);
    }
}
