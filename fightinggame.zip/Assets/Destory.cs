using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Destory : MonoBehaviour
{
    GameManagement gameManagement;
    private float topSideRange = -4.4f;
    private float bottomSideRange = 4.4f;
    // Start is called before the first frame update
    void Start()
    {
        gameManagement = FindObjectOfType<GameManagement>();
    }

    // Update is called once per frame
    void Update()
    {
        if (transform.position.z > bottomSideRange)
        {
            Destroy(gameObject);
        }
        else if (transform.position.z < topSideRange)
        {
            gameManagement.AddLives(-1);
            Destroy(gameObject);
        }
        
    }
    private void OnTriggerEnter(Collider other)
    {
        gameManagement.AddScore(5);
        Destroy(gameObject);
    }
}
